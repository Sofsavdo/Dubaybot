from aiogram import types, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.utils.keyboard import InlineKeyboardBuilder

from database.promo_codes import activate_promo

promo_router = Router()

# 💬 Promo kod holatini boshqarish uchun FSM
class PromoStates(StatesGroup):
    waiting_for_code = State()

# 🔘 /promo buyrug‘i orqali promo oynasini ochish
@promo_router.message(Command("promo"))
async def promo_command(message: types.Message, state: FSMContext):
    await message.answer("🎁 Promo code kiriting:")
    await state.set_state(PromoStates.waiting_for_code)

# 📩 Foydalanuvchi promo code kiritganda
@promo_router.message(PromoStates.waiting_for_code)
async def process_promo_code(message: types.Message, state: FSMContext):
    code = message.text.strip().upper()
    user_id = message.from_user.id

    result = activate_promo(user_id, code)

    if result["success"]:
        text = result["message"]

        # Agar promo code link va storega ega bo‘lsa, tugma bilan jo‘natamiz
        if result.get("link") and result.get("store"):
            builder = InlineKeyboardBuilder()
            builder.button(
                text=f"🔗 {result['store']} uchun ochish",
                url=result["link"]
            )
            await message.answer(text, reply_markup=builder.as_markup())
        else:
            await message.answer(text)
    else:
        await message.answer(f"❌ {result['message']}")

    await state.clear()
