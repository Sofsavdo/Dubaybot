from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from database.shop import get_all_shop_items, buy_item
from database.users import get_user_by_id
from bson import ObjectId

router = Router()

# 📦 Do‘kon menyusi
@router.message(F.text == "МАГАЗИН 🛍️")
async def show_shop(message: Message):
    items = get_all_shop_items()
    keyboard = InlineKeyboardMarkup(row_width=1)
    text = "🛍 <b>Do‘kondagi mahsulotlar:</b>\n\n"

    if not items:
        await message.answer("📭 Hozircha mahsulotlar mavjud emas.")
        return

    for item in items:
        item_id = str(item["_id"])
        title = item.get("title", "Nomaʼlum")
        price = item.get("price", 0)
        level_required = item.get("level_required", 0)
        stock = item.get("stock", 0)

        status = f"💰 {price} coin | 🧬 {level_required}-daraja | 📦 {stock} dona"
        button_text = f"{title} – {price}🪙"
        callback_data = f"buy_item:{item_id}"

        keyboard.inline_keyboard.append([
            InlineKeyboardButton(text=button_text, callback_data=callback_data)
        ])

        text += f"🔹 <b>{title}</b>\n{status}\n\n"

    await message.answer(text, reply_markup=keyboard)

# 🛒 Xarid qilish
@router.callback_query(F.data.startswith("buy_item:"))
async def handle_buy(call: CallbackQuery):
    item_id = call.data.split(":")[1]
    user_id = call.from_user.id

    result = buy_item(user_id, item_id)

    if result["success"]:
        item_title = result["item"].get("title", "Mahsulot")
        await call.message.answer(f"🎉 <b>{item_title}</b> mahsulotini xarid qildingiz!")
    else:
        await call.answer(result["message"], show_alert=True)
