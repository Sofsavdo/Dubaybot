from aiogram import Bot, Dispatcher, executor
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from dotenv import load_dotenv
import logging
import os
from admin_panel.routes.shop import shop_bp
app.register_blueprint(shop_bp, url_prefix='/admin/shop')
from bot.handlers.start import register_start_handlers
from bot.handlers.tap_game import register_tap_handlers
from bot.handlers.profile import register_profile_handlers
from bot.handlers.referrals import register_referral_handlers
from bot.handlers.shop import register_shop_handlers
from bot.handlers.balance import register_balance_handlers
from bot.handlers.boosters import register_booster_handlers
from admin.shop.routes import shop_bp
app.register_blueprint(shop_bp)

from bot.mini_games.daily_spin import register_daily_spin_handlers
from bot.mini_games.lootbox import register_lootbox_handlers
from bot.mini_games.memory_game import register_memory_game_handlers
from bot.mini_games.quiz_game import register_quiz_game_handlers

# Load env variables
load_dotenv()
API_TOKEN = os.getenv("BOT_TOKEN")

# Logging setup
logging.basicConfig(level=logging.INFO)

# Bot & Dispatcher
bot = Bot(token=API_TOKEN, parse_mode="HTML")
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)

async def on_startup(_):
    print("✅ Bot muvaffaqiyatli ishga tushdi.")

def register_all_handlers():
    register_start_handlers(dp)
    register_tap_handlers(dp)
    register_profile_handlers(dp)
    register_referral_handlers(dp)
    register_shop_handlers(dp)
    register_balance_handlers(dp)
    register_booster_handlers(dp)
    register_daily_spin_handlers(dp)
    register_lootbox_handlers(dp)
    register_memory_game_handlers(dp)
    register_quiz_game_handlers(dp)

if __name__ == "__main__":
    register_all_handlers()
    executor.start_polling(dp, skip_updates=True, on_startup=on_startup)
