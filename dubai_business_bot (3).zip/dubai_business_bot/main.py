import logging
from aiogram import Bot, Dispatcher, types
from aiogram.contrib.middlewares.logging import LoggingMiddleware
from aiogram.utils import executor

from mini_games.handlers import register_minigames
from mini_games.quiz_game import handle_quiz_answer
from admin_panel.routes.shop import shop_bp
app.register_blueprint(shop_bp, url_prefix='/admin/shop')
from handlers.shop import shop_router
dp.include_router(shop_router)
from handlers.shop_router import shop_router

dp.include_router(shop_router)

API_TOKEN = "YOUR_BOT_TOKEN_HERE"  # 🛑 Bu yerga bot tokeningizni yozing

# Bot va dispatcher
bot = Bot(token=API_TOKEN, parse_mode="HTML")
dp = Dispatcher(bot)
dp.middleware.setup(LoggingMiddleware())

# 🔗 Komandalar va callbacklarni ro‘yxatdan o‘tkazish
register_minigames(dp)
dp.register_callback_query_handler(handle_quiz_answer, lambda c: c.data.startswith("quiz:"))

# 🔥 Botni ishga tushirish
if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    print("🤖 Bot ishga tushdi...")
    executor.start_polling(dp, skip_updates=True)
