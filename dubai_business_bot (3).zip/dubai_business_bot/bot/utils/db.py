# utils/db.py

from pymongo import MongoClient
from config import MONGO_URI

client = MongoClient(MONGO_URI)
db = client['dubai_business']
users = db['users']

# 🧑‍💼 Foydalanuvchini olish
def get_user(user_id):
    return users.find_one({"user_id": user_id})

# ➕ Yangi foydalanuvchi yaratish
def create_user(user_id, username):
    if not get_user(user_id):
        user = {
            "user_id": user_id,
            "username": username,
            "coins": 0,
            "level": 1,
            "referrals": [],
            "energy": 100,
            "real_balance": 0,
            "booster_active": False
        }
        users.insert_one(user)

# 💰 Coin qo‘shish
def add_coins(user_id, amount):
    users.update_one({"user_id": user_id}, {"$inc": {"coins": amount}})

# 💵 Real balans qo‘shish
def add_real_balance(user_id, amount):
    users.update_one({"user_id": user_id}, {"$inc": {"real_balance": amount}})

# 🔋 Energy kamaytirish
def reduce_energy(user_id, amount):
    users.update_one({"user_id": user_id}, {"$inc": {"energy": -amount}})

# 🔋 Energy oshirish
def add_energy(user_id, amount):
    users.update_one({"user_id": user_id}, {"$inc": {"energy": amount}})

# 🚀 Booster holatini o‘zgartirish
def set_booster(user_id, is_active):
    users.update_one({"user_id": user_id}, {"$set": {"booster_active": is_active}})

# 🏆 Top foydalanuvchilarni olish (umumiy)
def get_top_users(limit=20):
    return users.find().sort("coins", -1).limit(limit)

# 🔍 Foydalanuvchi coin reytingi
def get_user_rank(user_id):
    all_users = list(users.find().sort("coins", -1))
    for index, user in enumerate(all_users, 1):
        if user["user_id"] == user_id:
            return index
    return None

# 🔍 Foydalanuvchilarni level bo‘yicha topish
def get_top_users_by_level(level, limit=20):
    query = {"level": level}
    return users.find(query).sort("coins", -1).limit(limit)

# 🔄 Barcha foydalanuvchilarni olish (level update uchun)
def get_all_users():
    return list(users.find())

# 🆙 Levelni yangilash
def update_user_level(user_id, new_level):
    users.update_one({"user_id": user_id}, {"$set": {"level": new_level}})

# ➕ Referral qo‘shish
def add_referral(user_id, ref_user_id):
    users.update_one({"user_id": user_id}, {"$addToSet": {"referrals": ref_user_id}})

# 🔢 Referral soni
def get_referral_count(user_id):
    user = get_user(user_id)
    if user and "referrals" in user:
        return len(user["referrals"])
    return 0

# 🧮 Foydalanuvchi balanslari
def get_user_balances(user_id):
    user = get_user(user_id)
    if not user:
        return 0, 0
    return user.get("coins", 0), user.get("real_balance", 0)

# 🆔 Foydalanuvchi mavjudligini tekshirish
def user_exists(user_id):
    return users.count_documents({"user_id": user_id}) > 0
