from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

main_menu = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="🎮 O‘yin"), KeyboardButton(text="👤 Profil")],
        [KeyboardButton(text="🏪 Do‘kon"), KeyboardButton(text="🎁 Promo Kod")],
        [KeyboardButton(text="📊 Reyting"), KeyboardButton(text="📤 Pul Yechish")],
    ],
    resize_keyboard=True
)

admin_menu = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="📋 Vazifalar"), KeyboardButton(text="➕ Yangi Promo")],
        [KeyboardButton(text="👥 Foydalanuvchilar"), KeyboardButton(text="📦 Buyurtmalar")],
        [KeyboardButton(text="⬅️ Ortga")],
    ],
    resize_keyboard=True
)
