from .default import main_menu, admin_menu
from .inline import profile_inline, shop_inline, promocode_confirm
