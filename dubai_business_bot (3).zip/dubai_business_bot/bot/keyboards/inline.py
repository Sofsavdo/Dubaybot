from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

# Profil bo‘limida
profile_inline = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="💸 Coin → So‘m", callback_data="convert_coin")],
    [InlineKeyboardButton(text="🔗 Referallarim", callback_data="my_referrals")],
    [InlineKeyboardButton(text="📈 Darajam", callback_data="my_level")]
])

# Do‘kon bo‘limida
shop_inline = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="🧢 Avatarlar", callback_data="shop_avatars")],
    [InlineKeyboardButton(text="🎁 Promo Kod Orqali", callback_data="shop_promocodes")],
    [InlineKeyboardButton(text="⚡ Booster", callback_data="shop_boosters")]
])

# Promokod tasdiqlash
def promocode_confirm(code):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"✅ Kodni faollashtirish: {code}", callback_data=f"use_promo:{code}")],
    ])
