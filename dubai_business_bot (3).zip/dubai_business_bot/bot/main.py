# bot/main.py
import asyncio
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from handlers import start

TOKEN = "YOUR_BOT_TOKEN"

async def main():
    bot = Bot(token=TOKEN, parse_mode="HTML")
    dp = Dispatcher(storage=MemoryStorage())

    dp.include_routers(
        start.router,
        # boshqa handlerlar ham shu yerga qo‘shiladi
    )

    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
