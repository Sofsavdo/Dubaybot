from aiogram import types
import random

lootbox_rewards = [
    {"type": "coin", "value": 25},
    {"type": "promo", "value": "LUCKY2025"},
    {"type": "booster", "value": 1},
    {"type": "nothing", "value": 0},
]

async def lootbox_open(message: types.Message):
    result = random.choice(lootbox_rewards)
    text = "📦 Siz ochgan sandiqdan: "

    if result['type'] == "coin":
        text += f"<b>{result['value']} Coin</b> chiqdi!"
    elif result['type'] == "promo":
        text += f"🎁 Promo kod: <code>{result['value']}</code>"
    elif result['type'] == "booster":
        text += "⚡ 2 daqiqa Booster faollashtirildi!"
    else:
        text += "❌ Afsuski, bo‘sh chiqdi."

    await message.answer(text, parse_mode="HTML")
