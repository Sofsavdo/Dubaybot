from aiogram import types
from aiogram.types import CallbackQuery
import random

quiz_data = [
    {
        "question": "🇺🇿 O‘zbekiston poytaxti qayer?",
        "options": ["Toshkent", "Buxoro", "Samarqand", "Andijon"],
        "answer": "Toshkent"
    },
    {
        "question": "🪙 1 USDT necha so‘mga teng (2025)?",
        "options": ["13,000", "14,500", "15,000", "12,000"],
        "answer": "14,500"
    }
]

async def start_quiz(message: types.Message):
    q = random.choice(quiz_data)
    keyboard = types.InlineKeyboardMarkup()
    for opt in q["options"]:
        keyboard.add(types.InlineKeyboardButton(text=opt, callback_data=f"quiz:{opt}:{q['answer']}"))
    
    await message.answer(f"❓ {q['question']}", reply_markup=keyboard)

async def handle_quiz_answer(call: CallbackQuery):
    _, user_answer, correct_answer = call.data.split(":")
    if user_answer == correct_answer:
        await call.message.edit_text("✅ To‘g‘ri! Sizga 20 coin berildi.")
        # update_user_coins(call.from_user.id, 20)
    else:
        await call.message.edit_text(f"❌ Noto‘g‘ri. To‘g‘ri javob: {correct_answer}")
