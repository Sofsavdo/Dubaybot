from aiogram import types
import random

async def play_memory_game(message: types.Message):
    emojis = ['🍎', '🍌', '🍇', '🍉']
    selected = random.sample(emojis, 2)
    mixed = selected + selected
    random.shuffle(mixed)

    display = "🧠 Xotira o‘yini\nEslab qol va juftlikni top: \n"
    for i, emoji in enumerate(mixed):
        display += f"{i+1}. [❓]\n"

    await message.answer(display + "\n(Tajriba versiyasi, to‘liq o‘yin keyinroq)")
