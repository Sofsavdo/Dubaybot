def register_daily_spin_handlers(dp):
    pass
