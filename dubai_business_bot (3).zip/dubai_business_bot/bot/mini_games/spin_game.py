from aiogram import types
import random
from database.users import update_user_coins

spin_rewards = [
    ("+10 💰", 10),
    ("+50 💰", 50),
    ("+1 ⚡ Booster", "booster"),
    ("🎁 Promo Kod", "promo"),
    ("❌ Hech narsa", 0),
]

async def daily_spin(message: types.Message):
    reward_text, reward_value = random.choice(spin_rewards)
    
    text = f"🎡 Ruletka aylantirildi!\nSiz yutdingiz: <b>{reward_text}</b>"

    if isinstance(reward_value, int) and reward_value > 0:
        update_user_coins(message.from_user.id, reward_value)
    elif reward_value == "promo":
        text += "\nSiz uchun bonus promo kod yuborildi!"
    elif reward_value == "booster":
        text += "\n⚡ Booster 2 daqiqa davomida faol bo‘ladi!"

    await message.answer(text, parse_mode="HTML")
