from .start import register_start
from .profile import register_profile
from .tap_game import register_tap_game
from .menu import register_menu

def register_all_handlers(dp):
    register_start(dp)
    register_profile(dp)
    register_tap_game(dp)
    register_menu(dp)
