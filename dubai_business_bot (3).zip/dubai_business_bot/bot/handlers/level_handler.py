from aiogram import types, Router
from utils.db import get_user
from utils.levels import get_level_info, next_level_requirements

router = Router()

@router.message(lambda msg: msg.text.lower() == "📈 уровень")
async def level_info_handler(message: types.Message):
    user_id = message.from_user.id
    user = get_user(user_id)

    if not user:
        await message.answer("Сначала нажмите /start чтобы зарегистрироваться.")
        return

    current_level = user.get("level", 1)
    coins = user.get("coins", 0)
    referrals = len(user.get("referrals", []))

    current_data = get_level_info(current_level)
    next_data = next_level_requirements(current_level)

    if not next_data:
        await message.answer("🏆 Вы уже достигли максимального уровня — <b>Император</b>!\nПоздравляем! 👑", parse_mode="HTML")
        return

    # Hisoblash
    coins_needed = max(0, next_data["coins_required"] - coins)
    referrals_needed = max(0, next_data["referrals_required"] - referrals)

    level_text = (
        f"📈 <b>Информация об уровне</b>\n\n"
        f"🔝 Ваш текущий уровень: <b>{current_level} — {current_data['name']}</b>\n\n"
        f"➡️ Следующий уровень: <b>{current_level + 1} — {next_data['name']}</b>\n"
        f"   ▫️ Нужны монеты: <b>{next_data['coins_required']}</b>\n"
        f"   ▫️ Нужны рефералы: <b>{next_data['referrals_required']}</b>\n\n"
        f"📊 Осталось:\n"
        f"   ▫️ Монет: <b>{coins_needed}</b>\n"
        f"   ▫️ Рефералов: <b>{referrals_needed}</b>\n\n"
    )

    if coins_needed == 0 and referrals_needed == 0:
        level_text += "✅ Вы готовы перейти на следующий уровень!\nНапишите администратору или ожидайте автоматического повышения."
    else:
        level_text += "🚀 Продолжайте собирать монеты и приглашать друзей, чтобы перейти на новый уровень!"

    await message.answer(level_text, parse_mode="HTML")
