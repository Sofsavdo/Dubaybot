from aiogram import Router, types
from utils.db import get_user
from utils.levels import can_level_up

router = Router()

@router.callback_query(lambda c: c.data == "check_next_level")
async def check_next_level_callback(call: types.CallbackQuery):
    user_id = call.from_user.id
    user = get_user(user_id)

    can_up, result = can_level_up(user)

    if can_up:
        text = (
            f"🎉 Вы можете перейти на следующий уровень!\n"
            f"Нажмите /levelup чтобы перейти на новый уровень: <b>{result['name']}</b>"
        )
    else:
        text = result  # bu holda stringli xabar bo'ladi

    await call.message.edit_text(text, parse_mode="HTML")
