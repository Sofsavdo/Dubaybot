from aiogram import Router, types, F
from aiogram.types import InputMediaPhoto
from database.users import get_user_by_id
from utils.format import format_coins, format_money

profile_router = Router()

@profile_router.message(F.text == "👤 Profil")
async def show_profile(message: types.Message):
    user_id = message.from_user.id
    user = get_user_by_id(user_id)

    if not user:
        await message.answer("Profil topilmadi.")
        return

    coins = user.get("coins", 0)
    level = user.get("level", 1)
    referrals = len(user.get("referrals", []))
    real_balance = user.get("real_balance", 0)
    avatar_url = user.get("avatar_url", None)
    booster = user.get("booster_active", False)

    status = "🟢 Faol" if booster else "⚪️ Yo‘q"

    text = f"""
👤 <b>Profil</b>
🆔 ID: <code>{user_id}</code>
📛 Ism: <b>{message.from_user.full_name}</b>
🎯 Daraja: <b>{level}</b>
🪙 Coinlar: <b>{format_coins(coins)}</b>
👥 Referallar: <b>{referrals} ta</b>
💰 Real balans: <b>{format_money(real_balance)}</b>
⚡ Booster: {status}
"""

    if avatar_url:
        await message.answer_photo(
            photo=avatar_url,
            caption=text,
            parse_mode="HTML"
        )
    else:
        await message.answer(text, parse_mode="HTML")
