import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
ADMINS = list(map(int, os.getenv("ADMINS", "").split(",")))
DB_NAME = "tap_to_earn_bot"
