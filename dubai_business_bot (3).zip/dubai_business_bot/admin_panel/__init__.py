from flask import Flask
from flask_cors import CORS
from database.users import get_all_users
from database.promocodes import get_all_promocodes

# 🔗 Blueprintlar
from admin_panel.routes.tasks import task_bp
from admin_panel.routes.promocodes import promocode_bp
from admin_panel.routes.users import user_bp
from admin_panel.routes.shop import shop_bp  # 🔥 SHOP BP QO‘SHILDI

app = Flask(__name__)
app.secret_key = 'securekey'  # ⚠️ .env faylga o‘tkazish tavsiya etiladi
CORS(app)

# 🔗 ROUTELARNI RO‘YXATDAN O‘TKAZISH
app.register_blueprint(task_bp, url_prefix='/admin/tasks')
app.register_blueprint(promocode_bp, url_prefix='/admin/promocodes')
app.register_blueprint(user_bp, url_prefix='/admin/users')
app.register_blueprint(shop_bp, url_prefix='/admin/shop')  # ✅ SHOP ROUTE

# 🏠 HOME SAHIFA
@app.route('/')
def home():
    users = list(get_all_users())
    promo_codes = list(get_all_promocodes())

    total_coins = sum(user.get("coins", 0) for user in users)
    user_count = len(users)
    promo_count = len(promo_codes)

    return f"""
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <title>Dubai Admin Panel</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                background: #0f0f0f;
                color: white;
                padding: 30px;
            }}
            h1 {{ color: #00ffd0; }}
            .section {{
                background: #1a1a1a;
                padding: 20px;
                border-radius: 10px;
                margin-bottom: 20px;
            }}
            a {{
                color: #00ffd0;
                text-decoration: none;
            }}
        </style>
    </head>
    <body>
        <h1>👑 Dubai Bot Admin Panel</h1>
        <div class="section">
            <h2>📊 Umumiy Statistika</h2>
            <p>Foydalanuvchilar soni: {user_count}</p>
            <p>Toplangan coinlar: {total_coins}</p>
            <p>Promo kodlar: {promo_count}</p>
        </div>
        <div class="section">
            <h2>🧾 Boshqaruv</h2>
            <a href="/admin/promocodes">🎁 Promo kodlar</a><br>
            <a href="/admin/tasks">📌 Topshiriqlar</a><br>
            <a href="/admin/users">👥 Foydalanuvchilar</a><br>
            <a href="/admin/shop">🛍 Do'kon</a>
        </div>
    </body>
    </html>
    """

# ▶️ LOCAL SERVERNI ISHLATISH
if __name__ == '__main__':
    app.run(debug=True)
