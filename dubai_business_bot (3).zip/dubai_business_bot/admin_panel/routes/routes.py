from flask import Blueprint, render_template, request, redirect, url_for
from database import users_col, tasks_col, promo_col, withdraw_col
from bson.objectid import ObjectId
from datetime import datetime

admin_bp = Blueprint('admin', __name__)


@admin_bp.route('/')
def dashboard():
    return render_template('dashboard.html')


@admin_bp.route('/users')
async def users():
    users_list = await users_col.find().to_list(length=100)
    return render_template('users.html', users=users_list)


@admin_bp.route('/tasks', methods=['GET', 'POST'])
async def tasks():
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        reward_type = request.form['reward_type']
        amount = int(request.form['amount'])
        link = request.form['link']

        reward = {reward_type: amount}
        new_task = {
            "title": title,
            "description": description,
            "reward": reward,
            "link": link,
            "created_at": datetime.utcnow(),
            "completed_by": []
        }
        await tasks_col.insert_one(new_task)
        return redirect(url_for('admin.tasks'))

    all_tasks = await tasks_col.find().to_list(length=100)
    return render_template('tasks.html', tasks=all_tasks)


@admin_bp.route('/promos', methods=['GET', 'POST'])
async def promos():
    if request.method == 'POST':
        code = request.form['code']
        description = request.form['description']
        reward_type = request.form['reward_type']
        amount = int(request.form['amount'])
        usage_limit = int(request.form['usage_limit'])

        reward = {reward_type: amount}
        new_promo = {
            "code": code,
            "description": description,
            "reward": reward,
            "usage_limit": usage_limit,
            "used_by": [],
            "created_at": datetime.utcnow()
        }
        await promo_col.insert_one(new_promo)
        return redirect(url_for('admin.promos'))

    all_promos = await promo_col.find().to_list(length=100)
    return render_template('promos.html', promos=all_promos)


@admin_bp.route('/withdraws')
async def withdraws():
    all_requests = await withdraw_col.find().to_list(length=100)
    return render_template('withdraws.html', requests=all_requests)


@admin_bp.route('/approve_withdraw/<request_id>')
async def approve_withdraw(request_id):
    await withdraw_col.update_one(
        {"_id": ObjectId(request_id)},
        {"$set": {"status": "approved"}}
    )
    return redirect(url_for('admin.withdraws'))
