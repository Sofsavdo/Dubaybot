from flask import Blueprint, render_template
from database import db

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/dashboard')
def dashboard():
    user_count = db.users.count_documents({})
    total_coins = db.users.aggregate([
        {"$group": {"_id": None, "total": {"$sum": "$coins"}}}
    ])
    total_coins = next(total_coins, {}).get("total", 0)
    promo_count = db.promocodes.count_documents({})

    return render_template('dashboard.html',
                           user_count=user_count,
                           total_coins=total_coins,
                           promo_count=promo_count)
