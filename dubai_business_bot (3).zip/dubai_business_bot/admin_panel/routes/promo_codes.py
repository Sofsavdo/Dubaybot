from flask import Blueprint, render_template, request, redirect, url_for
from database import db
from datetime import datetime

promo_bp = Blueprint('promocodes', __name__)

@promo_bp.route('/admin/promocodes')
def show_promocodes():
    promos = list(db.promocodes.find())
    return render_template('promocodes.html', promos=promos)

@promo_bp.route('/admin/promocodes/add', methods=['GET', 'POST'])
def add_promocode():
    if request.method == 'POST':
        code = request.form.get('code')
        description = request.form.get('description')
        reward_type = request.form.get('reward_type')  # 'coin', 'money', etc.
        reward_value = int(request.form.get('reward_value'))
        max_uses = int(request.form.get('max_uses'))

        db.promocodes.insert_one({
            'code': code,
            'description': description,
            'reward_type': reward_type,
            'reward_value': reward_value,
            'max_uses': max_uses,
            'used_by': [],
            'created_at': datetime.utcnow()
        })

        return redirect(url_for('promocodes.show_promocodes'))
    return render_template('add_promocode.html')

@promo_bp.route('/admin/promocodes/delete/<promo_id>', methods=['POST'])
def delete_promocode(promo_id):
    from bson import ObjectId
    db.promocodes.delete_one({'_id': ObjectId(promo_id)})
    return redirect(url_for('promocodes.show_promocodes'))
