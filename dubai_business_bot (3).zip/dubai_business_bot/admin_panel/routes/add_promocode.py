from flask import Blueprint, render_template, request, redirect, url_for
from routes.promo import create_promo

add_promocode_bp = Blueprint("add_promocode", __name__)

@add_promocode_bp.route("/add_promocode", methods=["GET", "POST"])
def add_promocode():
    if request.method == "POST":
        code = request.form.get("code")
        description = request.form.get("description")
        discount = request.form.get("discount")
        usage_limit = int(request.form.get("usage_limit"))
        link = request.form.get("link")
        create_promo(code, description, discount, usage_limit, link)
        return redirect(url_for("dashboard.dashboard"))  # yoki boshqa redirect
    return render_template("add_promocode.html")
