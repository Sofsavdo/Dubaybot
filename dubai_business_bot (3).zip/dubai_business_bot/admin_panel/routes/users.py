from flask import Blueprint, request, jsonify, render_template_string
from database.users import get_all_users, get_user, update_wallet, update_level

user_bp = Blueprint('users', __name__)

# 🔍 Barcha foydalanuvchilarni ko‘rsatish
@user_bp.route('/', methods=['GET'])
def list_users():
    users = list(get_all_users())
    html = """
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Foydalanuvchilar</title>
        <style>
            body {{
                font-family: Arial;
                background-color: #121212;
                color: white;
                padding: 20px;
            }}
            table {{
                border-collapse: collapse;
                width: 100%;
                background-color: #1e1e1e;
            }}
            th, td {{
                border: 1px solid #333;
                padding: 10px;
                text-align: left;
            }}
            th {{
                background-color: #00ffd0;
                color: black;
            }}
        </style>
    </head>
    <body>
        <h1>👥 Foydalanuvchilar ro'yxati</h1>
        <table>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Daraja</th>
                <th>Coin</th>
                <th>Real balans</th>
                <th>Hold balans</th>
                <th>Wallet</th>
            </tr>
            {% for user in users %}
            <tr>
                <td>{{ user.user_id }}</td>
                <td>{{ user.username }}</td>
                <td>{{ user.level }}</td>
                <td>{{ user.coins }}</td>
                <td>{{ user.real_balance }}</td>
                <td>{{ user.hold_balance }}</td>
                <td>{{ user.wallet or "Yo‘q" }}</td>
            </tr>
            {% endfor %}
        </table>
    </body>
    </html>
    """
    return render_template_string(html, users=users)

# 🎯 Wallet yangilash (API orqali)
@user_bp.route('/update_wallet', methods=['POST'])
def api_update_wallet():
    data = request.json
    user_id = data.get("user_id")
    wallet = data.get("wallet")

    if not user_id or not wallet:
        return jsonify({"error": "Ma'lumot yetarli emas"}), 400

    update_wallet(user_id, wallet)
    return jsonify({"message": "Wallet yangilandi"})

# 🎯 Daraja yangilash (API orqali)
@user_bp.route('/update_level', methods=['POST'])
def api_update_level():
    data = request.json
    user_id = data.get("user_id")
    level = data.get("level")

    if not user_id or not level:
        return jsonify({"error": "Ma'lumot yetarli emas"}), 400

    update_level(user_id, level)
    return jsonify({"message": "Daraja yangilandi"})
