# admin_panel/routes/promo_routes.py
from flask import Blueprint, render_template, request, redirect, url_for
from database import promo_codes

promo_bp = Blueprint('promocodes', __name__)

@promo_bp.route('/admin/promocodes')
def show_promocodes():
    promos = promo_codes.get_all_promos()
    return render_template('promocodes.html', promos=promos)

@promo_bp.route('/admin/promocodes/add', methods=['GET', 'POST'])
def add_promocode():
    if request.method == 'POST':
        code = request.form.get('code')
        description = request.form.get('description')
        reward = request.form.get('reward')
        usage_limit = request.form.get('usage_limit')
        link = request.form.get('link') or None
        discount = request.form.get('discount') or None

        promo_codes.add_promo(code, description, reward, usage_limit, link, discount)
        return redirect(url_for('promocodes.show_promocodes'))
    
    return render_template('add_promocode.html')

@promo_bp.route('/admin/promocodes/delete/<code>', methods=['POST'])
def delete_promocode(code):
    promo_codes.delete_promo(code)
    return redirect(url_for('promocodes.show_promocodes'))
