from flask import Blueprint, render_template, request, redirect, url_for, flash
from database.tasks import add_task, get_all_tasks, delete_task

task_bp = Blueprint('tasks', __name__, template_folder='../templates')

@task_bp.route('/admin/tasks')
def tasks():
    all_tasks = get_all_tasks()
    return render_template('tasks/tasks.html', tasks=all_tasks)

@task_bp.route('/admin/tasks/add', methods=['POST'])
def add_new_task():
    title = request.form.get('title')
    description = request.form.get('description')
    reward = request.form.get('reward')
    link = request.form.get('link')

    if not title or not description or not reward or not link:
        flash("❗ Barcha maydonlarni to‘ldiring.", "danger")
        return redirect(url_for('tasks.tasks'))

    add_task(title, description, reward, link)
    flash("✅ Vazifa muvaffaqiyatli qo‘shildi!", "success")
    return redirect(url_for('tasks.tasks'))

@task_bp.route('/admin/tasks/delete/<task_id>')
def delete_existing_task(task_id):
    delete_task(task_id)
    flash("🗑️ Vazifa o‘chirildi.", "info")
    return redirect(url_for('tasks.tasks'))
