from flask import Blueprint, render_template, request, redirect, url_for, flash
from database.promocodes import add_promocode, get_all_promocodes, delete_promocode

promocode_bp = Blueprint('promocodes', __name__, template_folder='../templates')

@promocode_bp.route('/admin/promocodes')
def promocodes():
    all_promo = get_all_promocodes()
    return render_template('promocodes/promocodes.html', promocodes=all_promo)

@promocode_bp.route('/admin/promocodes/add', methods=['POST'])
def add_new_promocode():
    code = request.form.get('code')
    description = request.form.get('description')
    reward = request.form.get('reward')
    max_uses = request.form.get('max_uses')
    link = request.form.get('link')

    if not code or not description or not reward or not max_uses:
        flash("❗ Barcha maydonlarni to‘ldiring.", "danger")
        return redirect(url_for('promocodes.promocodes'))

    add_promocode(code, description, int(reward), int(max_uses), link)
    flash("✅ Promo kod muvaffaqiyatli qo‘shildi!", "success")
    return redirect(url_for('promocodes.promocodes'))

@promocode_bp.route('/admin/promocodes/delete/<promo_id>')
def delete_existing_promocode(promo_id):
    delete_promocode(promo_id)
    flash("🗑️ Promo kod o‘chirildi.", "info")
    return redirect(url_for('promocodes.promocodes'))
