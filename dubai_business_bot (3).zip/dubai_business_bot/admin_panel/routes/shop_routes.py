from flask import Blueprint, render_template, request, redirect, url_for, flash
from database.shop import *
from bson.objectid import ObjectId

shop_bp = Blueprint("shop_bp", __name__, template_folder="templates")

@shop_bp.route("/admin/shop")
def admin_shop():
    items = get_all_shop_items()
    return render_template("admin/shop/shop_list.html", items=items)

@shop_bp.route("/admin/shop/add", methods=["GET", "POST"])
def add_shop_item_route():
    if request.method == "POST":
        title = request.form["title"]
        description = request.form["description"]
        price = int(request.form["price"])
        image_url = request.form["image_url"]
        category = request.form["category"]
        item_type = request.form["item_type"]
        level_required = int(request.form["level_required"])
        promo_link = request.form.get("promo_link")
        stock = int(request.form["stock"])
        is_active = "is_active" in request.form

        add_shop_item(title, description, price, image_url, category, is_active,
                      item_type, level_required, promo_link, stock)
        flash("Mahsulot muvaffaqiyatli qo‘shildi!", "success")
        return redirect(url_for("shop_bp.admin_shop"))

    return render_template("admin/shop/add_item.html")

@shop_bp.route("/admin/shop/edit/<item_id>", methods=["GET", "POST"])
def edit_shop_item(item_id):
    item = get_shop_item_by_id(item_id)

    if request.method == "POST":
        update_shop_item(
            item_id,
            title=request.form["title"],
            description=request.form["description"],
            price=int(request.form["price"]),
            image_url=request.form["image_url"],
            category=request.form["category"],
            item_type=request.form["item_type"],
            level_required=int(request.form["level_required"]),
            promo_link=request.form.get("promo_link"),
            stock=int(request.form["stock"]),
            is_active="is_active" in request.form
        )
        flash("Mahsulot yangilandi!", "success")
        return redirect(url_for("shop_bp.admin_shop"))

    return render_template("admin/shop/edit_item.html", item=item)

@shop_bp.route("/admin/shop/delete/<item_id>")
def delete_shop_item_route(item_id):
    delete_shop_item_by_id(item_id)
    flash("Mahsulot o‘chirildi.", "danger")
    return redirect(url_for("shop_bp.admin_shop"))

@shop_bp.route("/admin/shop/toggle/<item_id>")
def toggle_item_status(item_id):
    item = get_shop_item_by_id(item_id)
    if item:
        toggle_shop_item_status(item_id, not item.get("is_active", True))
        flash("Mahsulot holati o‘zgartirildi.", "info")
    return redirect(url_for("shop_bp.admin_shop"))
