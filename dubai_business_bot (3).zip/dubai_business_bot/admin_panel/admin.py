from flask_admin import BaseView, expose
from flask import request, render_template
from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017")
db = client["dubai_business"]
levels = db["levels"]

class LevelsAdmin(BaseView):
    @expose('/')
    def index(self):
        all_levels = list(levels.find().sort("level", 1))
        return render_template('admin_levels.html', levels=all_levels)

    @expose('/update', methods=['POST'])
    def update_level(self):
        level = int(request.form['level'])
        coin = int(request.form['coin_required'])
        referral = int(request.form['referral_required'])
        shop_price = int(request.form['shop_price'])

        levels.update_one(
            {"level": level},
            {"$set": {
                "coin_required": coin,
                "referral_required": referral,
                "shop_price": shop_price
            }},
            upsert=True
        )
        all_levels = list(levels.find().sort("level", 1))
        return render_template('admin_levels.html', levels=all_levels)
