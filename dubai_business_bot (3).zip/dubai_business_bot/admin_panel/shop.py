from flask import Blueprint, request, redirect
from database.shop import (
    add_shop_item, get_all_shop_items,
    delete_shop_item_by_id, get_shop_item_by_id,
    update_shop_item
)
from bson.objectid import ObjectId

shop_bp = Blueprint('shop_bp', __name__)

@shop_bp.route('/', methods=['GET', 'POST'])
def shop_panel():
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        price = int(request.form.get('price'))
        image_url = request.form.get('image_url')
        category = request.form.get('category') or "Umumiy"
        is_active = request.form.get('is_active') == 'on'

        add_shop_item(title, description, price, image_url, category, is_active)
        return redirect('/admin/shop')

    items = get_all_shop_items()
    html_items = ""
    for item in items:
        status = "🟢 Aktiv" if item.get("is_active", True) else "🔴 Passiv"
        html_items += f"""
            <div style='border:1px solid #444; padding:10px; margin:10px 0; border-radius:10px;'>
                <img src="{item['image_url']}" alt="{item['title']}" width="80"><br>
                <b>{item['title']}</b> <i>({item.get('category', 'Umumiy')})</i><br>
                {item['description']}<br>
                <b>{item['price']} coins</b><br>
                <small>{status}</small><br>
                <a href="/admin/shop/edit/{item['_id']}">✏️ Tahrirlash</a> | 
                <a href="/admin/shop/delete/{item['_id']}">🗑️ O'chirish</a>
            </div>
        """

    return f"""
    <html>
    <head><title>Shop Panel</title></head>
    <body style="background:#111; color:#fff; font-family:sans-serif; padding:30px;">
        <h2>🛍️ Do'kondagi mahsulotlar</h2>
        {html_items}

        <h3>➕ Yangi mahsulot qo‘shish</h3>
        <form method="post">
            <input name="title" placeholder="Nomi" required><br><br>
            <textarea name="description" placeholder="Tavsifi" required></textarea><br><br>
            <input name="price" type="number" placeholder="Coin narxi" required><br><br>
            <input name="image_url" placeholder="Rasm URL" required><br><br>
            <input name="category" placeholder="Kategoriya (ixtiyoriy)"><br><br>
            <label><input type="checkbox" name="is_active" checked> Mahsulot aktiv</label><br><br>
            <button type="submit">Qo‘shish</button>
        </form>
    </body>
    </html>
    """

@shop_bp.route('/delete/<item_id>')
def delete_item(item_id):
    delete_shop_item_by_id(item_id)
    return redirect('/admin/shop')

@shop_bp.route('/edit/<item_id>', methods=['GET', 'POST'])
def edit_item(item_id):
    item = get_shop_item_by_id(item_id)
    if not item:
        return "Mahsulot topilmadi", 404

    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        price = int(request.form.get('price'))
        image_url = request.form.get('image_url')
        category = request.form.get('category') or "Umumiy"
        is_active = request.form.get('is_active') == 'on'

        update_shop_item(item_id, title, description, price, image_url, category, is_active)
        return redirect('/admin/shop')

    is_active_checked = 'checked' if item.get("is_active", True) else ''

    return f"""
    <html>
    <head><title>Mahsulotni tahrirlash</title></head>
    <body style="background:#111; color:#fff; font-family:sans-serif; padding:30px;">
        <h2>✏️ Mahsulotni tahrirlash</h2>
        <form method="post">
            <input name="title" value="{item['title']}" required><br><br>
            <textarea name="description" required>{item['description']}</textarea><br><br>
            <input name="price" type="number" value="{item['price']}" required><br><br>
            <input name="image_url" value="{item['image_url']}" required><br><br>
            <input name="category" value="{item.get('category', '')}"><br><br>
            <label><input type="checkbox" name="is_active" {is_active_checked}> Mahsulot aktiv</label><br><br>
            <button type="submit">💾 Saqlash</button>
        </form>
        <br>
        <a href="/admin/shop" style="color:#0ff;">⬅️ Ortga</a>
    </body>
    </html>
    """
