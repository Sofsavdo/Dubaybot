from database import withdraw_col
from datetime import datetime

def create_withdraw_request(user_id, amount, wallet):
    request = {
        "user_id": user_id,
        "amount": amount,
        "wallet": wallet,
        "status": "pending",  # or approved, rejected
        "created_at": datetime.utcnow()
    }
    withdraw_col.insert_one(request)

def get_pending_requests():
    return list(withdraw_col.find({"status": "pending"}))

def approve_request(request_id):
    withdraw_col.update_one({"_id": request_id}, {"$set": {"status": "approved"}})

def reject_request(request_id):
    withdraw_col.update_one({"_id": request_id}, {"$set": {"status": "rejected"}})
