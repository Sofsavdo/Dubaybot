from pymongo import MongoClient
from bson.objectid import ObjectId
from datetime import datetime, timedelta
import random
import string

# MongoDB ulanish
client = MongoClient("mongodb://localhost:27017/")  # VPS bo‘lsa, URI ni shu yerga yozing
db = client["tap_to_earn_bot"]
users = db["users"]

# ✅ Foydalanuvchi olish yoki yaratish
def get_user(user_id: int):
    user = users.find_one({"user_id": user_id})
    if not user:
        referral_code = generate_referral_code(user_id)
        new_user = {
            "user_id": user_id,
            "coins": 0,
            "referrals": 0,
            "level": 1,
            "real_balance": 0,
            "booster_active": False,
            "booster_expires": None,
            "purchased_items": [],
            "wallet": None,
            "referral_code": referral_code,
            "invited_by": None,
            "banned": False,
            "active": True,
            "created_at": datetime.utcnow()
        }
        users.insert_one(new_user)
        return new_user
    return user

# 🔐 Ban va aktivlik
def ban_user(user_id: int):
    users.update_one({"user_id": user_id}, {"$set": {"banned": True}})

def unban_user(user_id: int):
    users.update_one({"user_id": user_id}, {"$set": {"banned": False}})

def is_banned(user_id: int) -> bool:
    user = get_user(user_id)
    return user.get("banned", False)

def set_active_status(user_id: int, status: bool):
    users.update_one({"user_id": user_id}, {"$set": {"active": status}})

def is_active(user_id: int) -> bool:
    user = get_user(user_id)
    return user.get("active", True)

# 🔁 Referal tizimi
def generate_referral_code(user_id: int) -> str:
    return f"DUBAI{user_id}"

def get_referral_link(user_id: int) -> str:
    return f"https://t.me/YOUR_BOT_USERNAME?start={generate_referral_code(user_id)}"

def set_invited_by(user_id: int, inviter_code: str):
    inviter = users.find_one({"referral_code": inviter_code})
    if inviter and inviter["user_id"] != user_id:
        users.update_one({"user_id": user_id}, {"$set": {"invited_by": inviter["user_id"]}})
        add_referral(inviter["user_id"])
        return True
    return False

def get_invited_by(user_id: int):
    user = get_user(user_id)
    return user.get("invited_by")

# 🧾 Statistika funksiyalari
def get_all_users():
    return list(users.find())

def get_top_users_by_coins(limit: int = 20):
    return list(users.find().sort("coins", -1).limit(limit))

def get_top_users_by_referrals(limit: int = 20):
    return list(users.find().sort("referrals", -1).limit(limit))

# 🟡 Yangilash funksiyasi
def update_user(user_id: int, update_fields: dict):
    get_user(user_id)
    users.update_one({"user_id": user_id}, {"$set": update_fields})

# 🪙 Coinlar
def update_user_coins(user_id: int, amount: int):
    get_user(user_id)
    users.update_one({"user_id": user_id}, {"$inc": {"coins": amount}})

def get_user_coins(user_id: int) -> int:
    user = get_user(user_id)
    return user.get("coins", 0)

# 💰 Real balans
def update_real_balance(user_id: int, amount: int):
    get_user(user_id)
    users.update_one({"user_id": user_id}, {"$inc": {"real_balance": amount}})

def get_real_balance(user_id: int) -> int:
    user = get_user(user_id)
    return user.get("real_balance", 0)

# 👥 Referallar
def add_referral(user_id: int):
    get_user(user_id)
    users.update_one({"user_id": user_id}, {"$inc": {"referrals": 1}})

# 🎯 Daraja
def level_up(user_id: int):
    get_user(user_id)
    users.update_one({"user_id": user_id}, {"$inc": {"level": 1}})

def get_user_level(user_id: int) -> int:
    user = get_user(user_id)
    return user.get("level", 1)

# ⚡ Booster
def activate_booster(user_id: int):
    get_user(user_id)
    expires_at = datetime.utcnow() + timedelta(minutes=2)
    users.update_one(
        {"user_id": user_id},
        {"$set": {"booster_active": True, "booster_expires": expires_at}}
    )

def check_booster_status(user_id: int) -> bool:
    user = get_user(user_id)
    if user.get("booster_active") and user.get("booster_expires"):
        if datetime.utcnow() >= user["booster_expires"]:
            users.update_one(
                {"user_id": user_id},
                {"$set": {"booster_active": False, "booster_expires": None}}
            )
            return False
        return True
    return False

# 🛍 Xaridlar
def add_purchased_item(user_id: int, item_id):
    get_user(user_id)
    users.update_one({"user_id": user_id}, {"$push": {"purchased_items": str(item_id)}})

def get_user_purchases(user_id: int):
    user = get_user(user_id)
    return user.get("purchased_items", [])

# 💳 Wallet
def set_user_wallet(user_id: int, wallet: str):
    get_user(user_id)
    users.update_one({"user_id": user_id}, {"$set": {"wallet": wallet}})

def get_user_wallet(user_id: int) -> str:
    user = get_user(user_id)
    return user.get("wallet", "")
