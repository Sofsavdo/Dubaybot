from pymongo import MongoClient
from datetime import datetime

client = MongoClient("mongodb://localhost:27017/")
db = client['dubai_business']
tasks_collection = db.tasks

# 🆕 Vazifa qo‘shish
def add_task(title, description, reward, link):
    tasks_collection.insert_one({
        "title": title,
        "description": description,
        "reward": int(reward),
        "link": link,
        "created_at": datetime.now()
    })

# 🔍 Barcha vazifalarni olish
def get_all_tasks():
    return list(tasks_collection.find())

# 🗑️ Vazifani o‘chirish
def delete_task(task_id):
    from bson.objectid import ObjectId
    tasks_collection.delete_one({"_id": ObjectId(task_id)})
