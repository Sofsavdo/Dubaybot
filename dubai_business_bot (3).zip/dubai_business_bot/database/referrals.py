from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017/")
db = client["tap_to_earn_bot"]
users = db["users"]

# Referal link yaratish (har bir user_id ga mos)
def get_referral_link(user_id: int) -> str:
    return f"https://t.me/dubai_business_bot?start={user_id}"

# Foydalanuvchi referal orqali qo‘shilganda uni yozish
def register_referral(user_id: int, referrer_id: int):
    if user_id == referrer_id:
        return False  # O‘zini taklif qila olmaydi

    user = users.find_one({"user_id": user_id})
    if user and user.get("referrer_id"):
        return False  # Allaqachon referal orqali kirgan

    referrer = users.find_one({"user_id": referrer_id})
    if not referrer:
        return False  # Taklif qilgan foydalanuvchi mavjud emas

    # Foydalanuvchini referer bilan bog‘laymiz
    users.update_one(
        {"user_id": user_id},
        {"$set": {"referrer_id": referrer_id}}
    )

    # Taklif qiluvchiga +1 referal qo‘shamiz
    users.update_one(
        {"user_id": referrer_id},
        {"$inc": {"referrals": 1}}
    )

    return True

# Referallar sonini olish
def get_user_referral_count(user_id: int) -> int:
    user = users.find_one({"user_id": user_id})
    return user.get("referrals", 0) if user else 0

# Kim taklif qilganini aniqlash
def get_user_referrer(user_id: int):
    user = users.find_one({"user_id": user_id})
    return user.get("referrer_id") if user else None
