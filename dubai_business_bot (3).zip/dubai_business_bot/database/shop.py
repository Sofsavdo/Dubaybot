from config.db import db
from bson.objectid import ObjectId
from datetime import datetime

# 🔵 Mahsulot qo‘shish
def add_shop_item(title, description, price, image_url, category="Umumiy", is_active=True,
                  item_type="general", level_required=0, promo_link=None, stock=100):
    db.shop.insert_one({
        "title": title,
        "description": description,
        "price": price,
        "image_url": image_url,
        "category": category,
        "is_active": is_active,
        "type": item_type,
        "level_required": level_required,
        "promo_link": promo_link,
        "stock": stock
    })

# 🟢 Barcha mahsulotlarni olish
def get_all_shop_items():
    return list(db.shop.find())

# ⚪ Faqat aktiv mahsulotlar
def get_active_shop_items():
    return list(db.shop.find({"is_active": True}))

# 🟡 Kategoriya bo‘yicha mahsulotlarni olish
def get_all_shop_items_by_category(category_name):
    return list(db.shop.find({"category": category_name, "is_active": True}))

# 🟣 Mahsulot turi bo‘yicha (promo, avatar, general)
def get_shop_items_by_type(item_type):
    return list(db.shop.find({"type": item_type, "is_active": True}))

# 🔄 So‘nggi qo‘shilgan mahsulotlar (admin uchun)
def get_latest_shop_items(limit=10):
    return list(db.shop.find({"is_active": True}).sort("_id", -1).limit(limit))

# 🟡 Mahsulotni ID orqali olish
def get_shop_item_by_id(item_id):
    return db.shop.find_one({"_id": ObjectId(item_id)})

# 📦 IDlar ro‘yxati orqali mahsulotlarni olish
def get_shop_items_by_ids(item_ids):
    object_ids = [ObjectId(i) for i in item_ids]
    return list(db.shop.find({"_id": {"$in": object_ids}}))

# 🟢 Promo mahsulotlarni olish
def get_promo_items():
    return list(db.shop.find({"type": "promo", "is_active": True}))

# 🔴 Mahsulotni o‘chirish
def delete_shop_item_by_id(item_id):
    db.shop.delete_one({"_id": ObjectId(item_id)})

# 🟣 Mahsulotni yangilash
def update_shop_item(item_id, title=None, description=None, price=None, image_url=None,
                     category=None, is_active=None, stock=None, item_type=None,
                     level_required=None, promo_link=None):
    update_fields = {}
    if title is not None: update_fields["title"] = title
    if description is not None: update_fields["description"] = description
    if price is not None: update_fields["price"] = price
    if image_url is not None: update_fields["image_url"] = image_url
    if category is not None: update_fields["category"] = category
    if is_active is not None: update_fields["is_active"] = is_active
    if stock is not None: update_fields["stock"] = stock
    if item_type is not None: update_fields["type"] = item_type
    if level_required is not None: update_fields["level_required"] = level_required
    if promo_link is not None: update_fields["promo_link"] = promo_link

    if update_fields:
        db.shop.update_one({"_id": ObjectId(item_id)}, {"$set": update_fields})

# 🟠 Aktiv/pasiv qilish
def toggle_shop_item_status(item_id, status: bool):
    db.shop.update_one({"_id": ObjectId(item_id)}, {"$set": {"is_active": status}})

# 🔻 Zaxiradan 1 dona kamaytirish
def decrease_stock(item_id):
    db.shop.update_one(
        {"_id": ObjectId(item_id), "stock": {"$gt": 0}},
        {"$inc": {"stock": -1}}
    )

# 🚫 Zaxira tugagan mahsulotlarni avtomatik o‘chirish
def check_and_deactivate_out_of_stock():
    out_of_stock_items = db.shop.find({"stock": {"$lte": 0}, "is_active": True})
    for item in out_of_stock_items:
        db.shop.update_one({"_id": item["_id"]}, {"$set": {"is_active": False}})

# ✅ Mahsulot sotib olish (coin evaziga)
def buy_item(user_id, item_id):
    user = db.users.find_one({"user_id": user_id})
    item = db.shop.find_one({"_id": ObjectId(item_id)})

    if not user or not item:
        return {"success": False, "message": "Foydalanuvchi yoki mahsulot topilmadi."}

    if str(item['_id']) in user.get("purchased_items", []):
        return {"success": False, "message": "Siz bu mahsulotni allaqachon xarid qilgansiz."}

    user_coins = user.get("coins", 0)
    item_price = item.get("price", 0)
    item_stock = item.get("stock", 0)
    level_required = item.get("level_required", 0)
    user_level = user.get("level", 1)

    if user_coins < item_price:
        return {"success": False, "message": "Yetarli coin mavjud emas."}

    if item_stock <= 0:
        return {"success": False, "message": "Mahsulot zaxirada qolmagan."}

    if user_level < level_required:
        return {"success": False, "message": f"Bu mahsulot faqat {level_required}-darajadan boshlab mavjud."}

    # Coinni kamaytirish, zaxirani kamaytirish, mahsulotni qo‘shish
    db.users.update_one(
        {"user_id": user_id},
        {
            "$inc": {"coins": -item_price},
            "$addToSet": {"purchased_items": str(item_id)}
        }
    )

    decrease_stock(item_id)
    check_and_deactivate_out_of_stock()

    # 🕓 Xarid tarixini log qilish
    db.purchase_history.insert_one({
        "user_id": user_id,
        "item_id": str(item_id),
        "item_title": item.get("title"),
        "price": item_price,
        "purchased_at": datetime.utcnow()
    })

    return {
        "success": True,
        "message": f"{item['title']} mahsuloti muvaffaqiyatli xarid qilindi!",
        "item": item,
        "item_name": item['title']
    }

# 🛍 Foydalanuvchining xarid qilgan mahsulotlari
def get_user_purchases(user_id):
    user = db.users.find_one({"user_id": user_id})
    if not user:
        return []
    purchased_ids = user.get("purchased_items", [])
    return list(db.shop.find({"_id": {"$in": [ObjectId(i) for i in purchased_ids]}}))

# 🔒 Admin tomonidan mahsulot qo‘shish (xarid emas)
def add_owned_item(user_id, item_id):
    db.users.update_one(
        {"user_id": user_id},
        {"$addToSet": {"purchased_items": str(item_id)}}
    )

# 📄 Foydalanuvchi xarid tarixi (admin ko‘rishi uchun)
def get_purchase_history_by_user(user_id):
    return list(db.purchase_history.find({"user_id": user_id}).sort("purchased_at", -1))

# ✅ Foydalanuvchi allaqachon xarid qilganini tekshirish
def has_purchased(user_id, item_id):
    user = db.users.find_one({"user_id": user_id})
    if not user:
        return False
    return str(item_id) in user.get("purchased_items", [])

# ❌ Mahsulotni mavjud emas deb belgilash (admin uchun)
def mark_item_unavailable(item_id):
    db.shop.update_one({"_id": ObjectId(item_id)}, {"$set": {"is_active": False, "stock": 0}})
