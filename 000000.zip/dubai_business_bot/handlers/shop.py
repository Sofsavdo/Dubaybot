# handlers/shop.py

from aiogram import Router, types, F
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from database.shop import get_all_shop_items_by_category, get_shop_item_by_id, decrease_stock
from database.users import get_user_by_id, update_user, add_owned_item

shop_router = Router()

# 🔘 CATEGORIES
CATEGORIES = [
    {"key": "avatar", "emoji": "🧍‍♂️", "name": "Avatarkalar"},
    {"key": "promo", "emoji": "🎁", "name": "Promo Kodlar"},
    {"key": "boost", "emoji": "⚡️", "name": "Boosterlar"},
    {"key": "other", "emoji": "📦", "name": "Boshqa"},
]

# 📁 1. Kategoriya keyboard
async def get_category_keyboard():
    buttons = []
    for cat in CATEGORIES:
        buttons.append([InlineKeyboardButton(
            text=f"{cat['emoji']} {cat['name']}",
            callback_data=f"shop_category_{cat['key']}"
        )])
    return InlineKeyboardMarkup(inline_keyboard=buttons)

# 🛒 2. Shop menyu (kategoriya tanlash)
@shop_router.message(F.text.lower().in_(["🛍 do‘kon", "🛒 do‘kon"]))
async def open_shop_menu(message: types.Message):
    await message.answer(
        "🛍 Do‘kon bo‘limiga xush kelibsiz! Qaysi turdagi mahsulotni ko‘rmoqchisiz?",
        reply_markup=await get_category_keyboard()
    )

# 🧾 3. Tanlangan kategoriya ichidagi mahsulotlar
@shop_router.callback_query(F.data.startswith("shop_category_"))
async def show_items_by_category(callback: types.CallbackQuery):
    category = callback.data.split("_")[-1]
    items = get_all_shop_items_by_category(category)

    if not items:
        await callback.message.edit_text("❌ Bu bo‘limda mahsulotlar mavjud emas.")
        return

    keyboard = []
    for item in items:
        keyboard.append([InlineKeyboardButton(
            text=f"{item['title']} - {item['price']}🪙",
            callback_data=f"shop_item_{item['_id']}"
        )])

    await callback.message.edit_text(
        "Mahsulotlardan birini tanlang:",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=keyboard)
    )

# 🛍 4. Mahsulotni ko‘rish va xarid qilish
@shop_router.callback_query(F.data.startswith("shop_item_"))
async def handle_shop_item(callback: types.CallbackQuery):
    item_id = callback.data.split("_")[-1]
    item = get_shop_item_by_id(item_id)
    user = get_user_by_id(callback.from_user.id)

    if not item or not user:
        await callback.answer("❌ Xatolik yuz berdi.", show_alert=True)
        return

    # ✅ Zaxira tekshiruvi
    if item.get("stock", 1) <= 0:
        await callback.answer("🚫 Bu mahsulot tugagan.", show_alert=True)
        return

    # ✅ Coin tekshiruvi
    user_coins = user.get("coins", 0)
    price = item["price"]

    if user_coins < price:
        await callback.answer("❌ Coin yetarli emas!", show_alert=True)
        return

    # ✅ Xarid amalga oshirish
    update_user(callback.from_user.id, {"coins": user_coins - price})
    add_owned_item(callback.from_user.id, item_id)
    decrease_stock(item_id)

    caption = f"✅ Siz <b>{item['title']}</b> mahsulotini {price}🪙 evaziga sotib oldingiz!\n\n📝 {item['description']}"

    if item.get("type") == "promo" and item.get("promo_code"):
        caption += f"\n\n🎁 Promo kod: <code>{item['promo_code']}</code>"

    await callback.message.answer_photo(
        photo=item["image_url"],
        caption=caption,
        parse_mode="HTML"
    )

    await callback.answer("Sotib olindi!")
