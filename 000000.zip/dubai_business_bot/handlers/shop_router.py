from aiogram import Router, types, F
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from database.shop import get_all_shop_items_by_category, get_shop_item_by_id, buy_item

shop_router = Router()

# 🔘 Do'kondagi mahsulot kategoriyalari
CATEGORIES = [
    {"key": "avatar", "emoji": "🫍‍♂️", "name": "Avatarkalar"},
    {"key": "promo", "emoji": "🏱", "name": "Promo Kodlar"},
    {"key": "boost", "emoji": "⚡️", "name": "Boosterlar"},
    {"key": "Umumiy", "emoji": "📂", "name": "Boshqa"},
]

# 🔘 Kategoriya tanlash uchun tugmalar
async def get_category_keyboard():
    buttons = []
    for cat in CATEGORIES:
        buttons.append([InlineKeyboardButton(
            text=f"{cat['emoji']} {cat['name']}",
            callback_data=f"shop_category_{cat['key']}"
        )])
    return InlineKeyboardMarkup(inline_keyboard=buttons)

# 🛒 Do'kon menyusi
@shop_router.message(F.text == "🛒 Do‘kon")
async def open_shop_menu(message: types.Message):
    await message.answer("🏣 Do‘kon bo‘limiga xush kelibsiz! Qaysi turdagi mahsulotni ko‘rmoqchisiz:",
                         reply_markup=await get_category_keyboard())

# 🗂 Kategoriya tanlangandan keyin mahsulotlar ro'yxati
@shop_router.callback_query(F.data.startswith("shop_category_"))
async def show_items_by_category(callback: types.CallbackQuery):
    category = callback.data.split("_")[-1]
    items = get_all_shop_items_by_category(category)

    if not items:
        await callback.message.edit_text("❌ Bu bo‘limda hozircha mahsulotlar mavjud emas.")
        return

    keyboard = []
    for item in items:
        keyboard.append([InlineKeyboardButton(
            text=f"{item['title']} - {item['price']}🪙",
            callback_data=f"shop_item_{item['_id']}"
        )])

    await callback.message.edit_text("🧾 Mahsulotlardan birini tanlang:",
                                     reply_markup=InlineKeyboardMarkup(inline_keyboard=keyboard))

# ✅ Mahsulot xarid qilish
@shop_router.callback_query(F.data.startswith("shop_item_"))
async def handle_shop_item(callback: types.CallbackQuery):
    item_id = callback.data.split("_")[-1]
    result = buy_item(callback.from_user.id, item_id)

    if not result["success"]:
        await callback.answer(result["message"], show_alert=True)
        return

    item = result["item"]
    caption = f"✅ Siz <b>{item['title']}</b> mahsulotini {item['price']}🪙 evaziga xarid qildingiz!\n\n📝 {item['description']}"

    if item.get("type") == "promo" and item.get("promo_link"):
        caption += f"\n\n🎁 <a href='{item['promo_link']}'>Promo linkdan foydalanish</a>"

    await callback.message.answer_photo(
        photo=item["image_url"],
        caption=caption,
        parse_mode="HTML"
    )
    await callback.answer("✅ Xarid muvaffaqiyatli amalga oshirildi!")
