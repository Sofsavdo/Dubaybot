from aiogram import Router, types, F
from aiogram.filters import Command
from aiogram.utils.markdown import hbold
from keyboards.default import main_menu
from database.promo_codes import activate_promo, get_user_promos

router = Router()

@router.message(Command("promo"))
async def promo_start(message: types.Message):
    await message.answer(
        "🎁 Введите промо-код, который вы хотите активировать:",
        reply_markup=types.ReplyKeyboardRemove()
    )
    await message.answer("❗ Чтобы вернуться в главное меню, нажмите /menu")
    await message.bot.set_state(message.from_user.id, "waiting_for_promo")

@router.message(F.text, state="waiting_for_promo")
async def activate_promo_code(message: types.Message):
    code = message.text.strip()
    user_id = message.from_user.id
    result = activate_promo(user_id, code)

    if result["success"]:
        text = f"✅ {result['message']}"
        if result["link"]:
            text += f"\n🔗 Ссылка: {result['link']}"
        if result["store"]:
            text += f"\n🏪 Магазин: {result['store']}"
        await message.answer(text, reply_markup=main_menu())
    else:
        await message.answer(f"❌ {result['message']}", reply_markup=main_menu())

    await message.bot.reset_state(message.from_user.id)


@router.message(Command("my_promos"))
async def my_promos(message: types.Message):
    user_id = message.from_user.id
    promos = get_user_promos(user_id)

    if not promos:
        await message.answer("😕 Вы еще не активировали ни одного промо-кода.")
        return

    msg = f"🧾 {hbold('Ваши использованные промо-коды')}:\n\n"
    for promo in promos:
        reward = f"{promo['value']} монет" if promo['reward_type'] == "coins" else promo['reward_type']
        msg += f"🔹 {promo['code']} – {reward}\n📄 {promo['description']}\n\n"

    await message.answer(msg)
