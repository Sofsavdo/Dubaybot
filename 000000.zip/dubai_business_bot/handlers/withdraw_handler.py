# 👇 /handlers/withdraw_handler.py
from aiogram import Router, types, F
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message
from database.users import get_user, update_wallet
from database.withdrawals import add_withdrawal_request
from keyboards.inline import confirm_withdraw_kb

router = Router()

class WithdrawForm(StatesGroup):
    enter_wallet = State()
    enter_amount = State()

@router.message(F.text == "\ud83d\udcb8 Pul yechish")
async def withdraw_entry(msg: Message, state: FSMContext):
    user = get_user(msg.from_user.id)
    if user['real_balance'] < 145000:
        await msg.answer("\u274c Pul yechish uchun eng kam balans: <b>145,000 so'm</b>", parse_mode="HTML")
        return
    await msg.answer("\ud83d\udcb3 Pul yuborish uchun kartangiz yoki crypto wallet manzilingizni kiriting:")
    await state.set_state(WithdrawForm.enter_wallet)

@router.message(WithdrawForm.enter_wallet)
async def process_wallet(msg: Message, state: FSMContext):
    await state.update_data(wallet=msg.text)
    await msg.answer("\ud83d\udcc5 Qancha miqdorda yechmoqchisiz? So'mda yozing:")
    await state.set_state(WithdrawForm.enter_amount)

@router.message(WithdrawForm.enter_amount)
async def process_amount(msg: Message, state: FSMContext):
    data = await state.get_data()
    user = get_user(msg.from_user.id)
    try:
        amount = int(msg.text)
    except:
        await msg.answer("\u274c Miqdorni son bilan yozing!")
        return

    if amount < 145000:
        await msg.answer("\u274c Minimal yechish: <b>145,000 so'm</b>", parse_mode="HTML")
        return
    if user['real_balance'] < amount:
        await msg.answer("\u274c Sizda bu miqdorda balans mavjud emas!", parse_mode="HTML")
        return

    await add_withdrawal_request(user['user_id'], amount, data['wallet'])
    await msg.answer(
        f"\ud83d\ude80 So'rov yuborildi!\n\n<b>Miqdor:</b> {amount} so'm\n<b>Wallet:</b> {data['wallet']}\n\nAdmin tekshiruviga yuborildi. 72 soat ichida ko'rib chiqiladi.",
        parse_mode="HTML")
    await state.clear()
