from flask import Blueprint, render_template, request, redirect, url_for
from database.shop import add_shop_item, get_all_shop_items, delete_shop_item_by_id

shop_bp = Blueprint("shop_bp", __name__, template_folder="templates")

# 🔹 Mahsulotlar ro'yxati
@shop_bp.route('/shop')
def shop_items():
    items = get_all_shop_items()
    return render_template('shop.html', items=items)

# 🔹 Mahsulot qo‘shish sahifasi
@shop_bp.route('/shop/add', methods=["GET", "POST"])
def add_item():
    if request.method == "POST":
        title = request.form.get("title")
        description = request.form.get("description")
        price = int(request.form.get("price"))
        image_url = request.form.get("image_url")
        add_shop_item(title, description, price, image_url)
        return redirect(url_for('shop_bp.shop_items'))
    return render_template("add_shop_item.html")

# 🔹 Mahsulot o‘chirish
@shop_bp.route('/shop/delete/<item_id>')
def delete_item(item_id):
    delete_shop_item_by_id(item_id)
    return redirect(url_for('shop_bp.shop_items'))
