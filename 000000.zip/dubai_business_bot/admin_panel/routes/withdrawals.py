from flask import Blueprint, render_template, redirect, url_for, flash
from bson.objectid import ObjectId
from database.withdrawals import get_all_withdrawals, approve_withdrawal, reject_withdrawal

withdrawal_bp = Blueprint('withdrawals', __name__, template_folder='../templates')

# 📋 Withdrawallar ro‘yxati
@withdrawal_bp.route('/admin/withdrawals')
def list_withdrawals():
    withdrawals = get_all_withdrawals()
    return render_template('withdrawals/withdrawals.html', withdrawals=withdrawals)

# ✅ Tasdiqlash
@withdrawal_bp.route('/admin/withdrawals/approve/<request_id>')
def approve_request(request_id):
    approve_withdrawal(ObjectId(request_id))
    flash("✅ Pul yechish so‘rovi tasdiqlandi!", "success")
    return redirect(url_for('withdrawals.list_withdrawals'))

# ❌ Rad etish
@withdrawal_bp.route('/admin/withdrawals/reject/<request_id>')
def reject_request(request_id):
    reject_withdrawal(ObjectId(request_id))
    flash("❌ Pul yechish so‘rovi rad etildi.", "danger")
    return redirect(url_for('withdrawals.list_withdrawals'))
