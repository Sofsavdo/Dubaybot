from flask import Blueprint, render_template, request, redirect, url_for, flash
from database.withdraw_requests import get_all_withdraw_requests, update_withdraw_status
from datetime import datetime

withdraw_bp = Blueprint("withdraw", __name__)

@withdraw_bp.route('/withdraws')
def view_withdraws():
    requests = get_all_withdraw_requests()
    return render_template('withdraws.html', withdraw_requests=requests)

@withdraw_bp.route('/withdraws/update/<request_id>', methods=['POST'])
def update_withdraw(request_id):
    new_status = request.form.get('status')
    update_withdraw_status(request_id, new_status)
    flash("So‘rov yangilandi!", "success")
    return redirect(url_for('withdraw.view_withdraws'))
