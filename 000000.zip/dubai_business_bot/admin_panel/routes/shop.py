from flask import Blueprint, request, redirect, url_for, render_template_string
from database.shop import (
    get_all_shop_items, add_shop_item, delete_shop_item_by_id,
    get_shop_item_by_id, update_shop_item
)

shop_bp = Blueprint('shop', __name__)

# 📄 Barcha mahsulotlarni ko‘rish
@shop_bp.route('/', methods=['GET'])
def shop_index():
    items = get_all_shop_items()
    html = """
    <html>
    <head>
        <title>🛍 Mahsulotlar</title>
        <style>
            body {{
                font-family: Arial;
                background: #0f0f0f;
                color: white;
                padding: 30px;
            }}
            h1 {{ color: #00ffd0; }}
            table {{
                width: 100%;
                background: #1a1a1a;
                border-collapse: collapse;
                margin-top: 20px;
            }}
            th, td {{
                border: 1px solid #444;
                padding: 10px;
                text-align: left;
            }}
            a {{ color: #00ffd0; }}
            input, textarea {{
                width: 100%;
                padding: 8px;
                margin: 5px 0;
                border-radius: 5px;
                border: none;
            }}
            button {{
                background: #00ffd0;
                border: none;
                padding: 10px;
                border-radius: 5px;
                cursor: pointer;
            }}
        </style>
    </head>
    <body>
        <h1>🛍 Mahsulotlar bo‘limi</h1>

        <h2>➕ Mahsulot qo‘shish</h2>
        <form method="POST" action="/admin/shop/add">
            <input type="text" name="title" placeholder="Nomi" required>
            <textarea name="description" placeholder="Tavsifi" required></textarea>
            <input type="number" name="price" placeholder="Coin narxi" required>
            <input type="text" name="image_url" placeholder="Rasm URL (https://...)">
            <button type="submit">Qo‘shish</button>
        </form>

        <h2>📦 Mavjud mahsulotlar</h2>
        <table>
            <tr>
                <th>Nomi</th>
                <th>Tavsif</th>
                <th>Narx</th>
                <th>Rasm</th>
                <th>Amallar</th>
            </tr>
            {% for item in items %}
            <tr>
                <td>{{ item['title'] }}</td>
                <td>{{ item['description'] }}</td>
                <td>{{ item['price'] }} 🪙</td>
                <td><img src="{{ item['image_url'] }}" width="60"></td>
                <td>
                    <a href="/admin/shop/delete/{{ item['_id'] }}">❌ O‘chirish</a>
                </td>
            </tr>
            {% endfor %}
        </table>
        <br>
        <a href="/">⬅️ Orqaga</a>
    </body>
    </html>
    """
    return render_template_string(html, items=items)


# ➕ Mahsulot qo‘shish
@shop_bp.route('/add', methods=['POST'])
def add_product():
    title = request.form.get('title')
    description = request.form.get('description')
    price = int(request.form.get('price'))
    image_url = request.form.get('image_url') or "https://via.placeholder.com/100"

    add_shop_item(title, description, price, image_url)
    return redirect(url_for('shop.shop_index'))

# ❌ Mahsulotni o‘chirish
@shop_bp.route('/delete/<item_id>')
def delete_product(item_id):
    delete_shop_item_by_id(item_id)
    return redirect(url_for('shop.shop_index'))
