from pymongo import MongoClient
from bson.objectid import ObjectId
from datetime import datetime
import os

# MongoDB ulanish
client = MongoClient(os.getenv("MONGO_URL", "mongodb://localhost:27017/"))
db = client["tap_to_earn_bot"]
promo_collection = db["promo_codes"]

# Promo yaratish
def create_promo(code, description, discount, usage_limit, link):
    promo = {
        "code": code,
        "description": description,
        "discount": discount,
        "usage_limit": usage_limit,
        "link": link,
        "created_at": datetime.utcnow()
    }
    promo_collection.insert_one(promo)

# Barcha promo'larni olish
def get_all_promos():
    return list(promo_collection.find())

# Promo o'chirish
def delete_promo(promo_id):
    promo_collection.delete_one({"_id": ObjectId(promo_id)})
