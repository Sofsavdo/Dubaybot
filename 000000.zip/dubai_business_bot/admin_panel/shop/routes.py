from flask import Blueprint, render_template, request, redirect, url_for, flash
from database.shop import (
    get_all_shop_items,
    get_shop_item_by_id,
    add_shop_item,
    update_shop_item,
    delete_shop_item_by_id,
    toggle_shop_item_status
)

shop_bp = Blueprint('shop', __name__, url_prefix='/admin')

# === Show All Shop Items ===
@shop_bp.route('/shop')
def shop_list():
    items = get_all_shop_items()
    return render_template('admin/shop/shop_list.html', items=items)


# === Add New Shop Item ===
@shop_bp.route('/shop/add', methods=['GET', 'POST'])
def add_shop_item_route():
    if request.method == 'POST':
        try:
            title = request.form.get('title', '').strip()
            description = request.form.get('description', '').strip()
            price = int(request.form.get('price', 0))
            image_url = request.form.get('image_url', '').strip()
            category = request.form.get('category', '').strip()
            item_type = request.form.get('type', '').strip()
            level_required = int(request.form.get('level_required', 0))
            promo_link = request.form.get('promo_link', '').strip()
            is_active = request.form.get('is_active') == 'on'

            add_shop_item(title, description, price, image_url, category, is_active, item_type, level_required, promo_link)
            flash("🛒 Item successfully added!", "success")
            return redirect(url_for('shop.shop_list'))
        except Exception as e:
            flash(f"❌ Error adding item: {e}", "danger")
            return redirect(url_for('shop.add_shop_item_route'))

    return render_template('admin/shop/add_item.html')


# === Edit Existing Shop Item ===
@shop_bp.route('/shop/edit/<item_id>', methods=['GET', 'POST'])
def edit_shop_item(item_id):
    item = get_shop_item_by_id(item_id)
    if not item:
        flash("⚠️ Item not found.", "warning")
        return redirect(url_for('shop.shop_list'))

    if request.method == 'POST':
        try:
            update_shop_item(
                item_id,
                title=request.form.get('title', '').strip(),
                description=request.form.get('description', '').strip(),
                price=int(request.form.get('price', 0)),
                image_url=request.form.get('image_url', '').strip(),
                category=request.form.get('category', '').strip(),
                type=request.form.get('type', '').strip(),
                level_required=int(request.form.get('level_required', 0)),
                promo_link=request.form.get('promo_link', '').strip(),
                is_active=request.form.get('is_active') == 'on'
            )
            flash("✏️ Item updated successfully!", "success")
            return redirect(url_for('shop.shop_list'))
        except Exception as e:
            flash(f"❌ Error editing item: {e}", "danger")
            return redirect(url_for('shop.edit_shop_item', item_id=item_id))

    return render_template('admin/shop/edit_item.html', item=item)


# === Delete Shop Item ===
@shop_bp.route('/shop/delete/<item_id>')
def delete_shop_item_route(item_id):
    delete_shop_item_by_id(item_id)
    flash("🗑️ Item deleted.", "info")
    return redirect(url_for('shop.shop_list'))


# === Toggle Item Status ===
@shop_bp.route('/shop/toggle/<item_id>')
def toggle_item_status(item_id):
    item = get_shop_item_by_id(item_id)
    if not item:
        flash("⚠️ Item not found.", "warning")
        return redirect(url_for('shop.shop_list'))

    new_status = not item.get('is_active', True)
    toggle_shop_item_status(item_id, new_status)
    status_msg = "activated" if new_status else "deactivated"
    flash(f"🔄 Item {status_msg}.", "success")
    return redirect(url_for('shop.shop_list'))
