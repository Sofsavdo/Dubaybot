from database.users import get_all_users
from database.promocodes import get_all_promocodes

def get_user_count():
    users = get_all_users()
    return len(users)

def get_total_coins():
    users = get_all_users()
    return sum(user.get("coins", 0) for user in users)

def get_promo_count():
    promocodes = get_all_promocodes()
    return len(promocodes)
