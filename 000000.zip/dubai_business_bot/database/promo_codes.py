from pymongo import MongoClient
from datetime import datetime

client = MongoClient("mongodb://localhost:27017/")  # yoki Contabo URI
db = client["tap_to_earn_bot"]
promo_codes = db["promo_codes"]
users = db["users"]

# 🟢 Promo code qo‘shish
def create_promo(code: str, description: str, reward_type: str, value, limit: int = 1, link: str = None, store: str = None, is_active: bool = True):
    promo_codes.insert_one({
        "code": code.upper(),
        "description": description,
        "reward_type": reward_type,  # coins, booster, real_balance, custom_reward
        "value": value,
        "limit": limit,
        "used_by": [],
        "is_active": is_active,
        "link": link,
        "store": store,
        "created_at": datetime.utcnow()
    })

# 🔵 Barcha promo codeni olish (admin uchun)
def get_all_promos():
    return list(promo_codes.find())

# 🟡 Faqat aktiv promo kodlar
def get_active_promos():
    return list(promo_codes.find({"is_active": True}))

# 🧾 Promo code ni topish
def get_promo_by_code(code: str):
    return promo_codes.find_one({"code": code.upper()})

# 🟣 Promo code faollashtirish (foydalanuvchi tomonidan)
def activate_promo(user_id: int, code: str):
    promo = get_promo_by_code(code)
    if not promo or not promo["is_active"]:
        return {"success": False, "message": "Promo code mavjud emas yoki aktiv emas."}

    if user_id in promo.get("used_by", []):
        return {"success": False, "message": "Siz bu promo code'dan foydalanib bo‘lgansiz."}

    if len(promo["used_by"]) >= promo["limit"]:
        return {"success": False, "message": "Promo code limiti tugagan."}

    # 🎁 Mukofotni berish
    reward_type = promo["reward_type"]
    value = promo["value"]

    if reward_type == "coins":
        users.update_one({"user_id": user_id}, {"$inc": {"coins": value}})
    elif reward_type == "real_balance":
        users.update_one({"user_id": user_id}, {"$inc": {"real_balance": value}})
    elif reward_type == "booster":
        expires = datetime.utcnow() + timedelta(minutes=2)
        users.update_one({"user_id": user_id}, {"$set": {"booster_active": True, "booster_expires": expires}})
    elif reward_type == "custom_reward":
        # Bu maxsus promo bo‘lsa, faqat description va link ko‘rsatiladi
        pass

    # 🔐 Foydalanuvchini used_by ro‘yxatiga qo‘shamiz
    promo_codes.update_one({"code": code.upper()}, {"$push": {"used_by": user_id}})

    return {
        "success": True,
        "message": f"{promo['description']}\n🎉 Promo code faollashtirildi!",
        "reward_type": reward_type,
        "value": value,
        "link": promo.get("link"),
        "store": promo.get("store")
    }

# ❌ Promo code ni o‘chirish
def delete_promo(code: str):
    promo_codes.delete_one({"code": code.upper()})

# ⚙️ Promo code holatini almashtirish (aktiv/pasiv)
def toggle_promo_status(code: str, status: bool):
    promo_codes.update_one({"code": code.upper()}, {"$set": {"is_active": status}})

# 🧾 Foydalanuvchining promo tarixini olish
def get_user_promos(user_id: int):
    return list(promo_codes.find({"used_by": user_id}))
