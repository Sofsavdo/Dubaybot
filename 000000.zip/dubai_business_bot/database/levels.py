from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017/")
db = client["tap_to_earn_bot"]
levels = db["levels"]
users = db["users"]

# Har bir darajaga talab qo‘yish (admin tomonidan)
def set_level_requirement(level: int, required_coins: int, required_referrals: int, shop_price: int = None):
    data = {
        "level": level,
        "required_coins": required_coins,
        "required_referrals": required_referrals,
        "shop_price": shop_price  # Ixtiyoriy: agar foydalanuvchi coin bilan xarid qilmoqchi bo‘lsa
    }
    levels.update_one({"level": level}, {"$set": data}, upsert=True)

# Foydalanuvchi hozirgi darajasini olish
def get_user_level(user_id: int):
    user = users.find_one({"user_id": user_id})
    if user:
        return user.get("level", 1)
    return 1

# Ma'lum darajadagi talablarni olish
def get_level_requirements(level: int):
    return levels.find_one({"level": level})

# Foydalanuvchini keyingi darajaga oshirish (agar shartlar bajarilgan bo‘lsa)
def try_level_up(user_id: int):
    user = users.find_one({"user_id": user_id})
    if not user:
        return {"success": False, "reason": "Foydalanuvchi topilmadi"}

    current_level = user.get("level", 1)
    next_level = current_level + 1
    requirements = levels.find_one({"level": next_level})

    if not requirements:
        return {"success": False, "reason": "Keyingi daraja mavjud emas"}

    user_coins = user.get("coins", 0)
    user_referrals = user.get("referrals", 0)

    if user_coins >= requirements["required_coins"] and user_referrals >= requirements["required_referrals"]:
        users.update_one(
            {"user_id": user_id},
            {"$set": {"level": next_level}}
        )
        return {"success": True, "new_level": next_level}
    
    # Qaysi shart bajarilmaganini qaytaramiz
    missing = []
    if user_coins < requirements["required_coins"]:
        missing.append(f"{requirements['required_coins'] - user_coins} ta coin yetarli emas")
    if user_referrals < requirements["required_referrals"]:
        missing.append(f"{requirements['required_referrals'] - user_referrals} ta referal yetarli emas")

    return {"success": False, "reason": "va".join(missing)}

# Darajani majburan coin orqali sotib olish (admin do‘konidan)
def force_level_up_with_shop(user_id: int, level: int):
    user = users.find_one({"user_id": user_id})
    requirements = levels.find_one({"level": level})

    if not user or not requirements or not requirements.get("shop_price"):
        return False

    if user.get("coins", 0) >= requirements["shop_price"]:
        users.update_one(
            {"user_id": user_id},
            {
                "$set": {"level": level},
                "$inc": {"coins": -requirements["shop_price"]}
            }
        )
        return True
    return False
