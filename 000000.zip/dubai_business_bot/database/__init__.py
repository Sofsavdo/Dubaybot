# database/__init__.py
from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017/")
db = client["dubai_business"]

users_col = db["users"]
promo_col = db["promo_codes"]
tasks_col = db["tasks"]
withdraw_col = db["withdraw_requests"]
shop_col = db["shop"]
levels_col = db["levels"]
