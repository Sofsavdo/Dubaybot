# init_levels.py
from pymongo import MongoClient

# 🔗 Mongo manzil
MONGO_URI = "mongodb://localhost:27017"
client = MongoClient(MONGO_URI)
db = client['dubai_business']
levels = db['levels']

# 🔁 Avvalgi yozuvlarni tozalaymiz
levels.delete_many({})

# 📊 LEVELS ma’lumotlari
LEVELS_DATA = [
    {"level": 1, "name": "Новичок",        "coins_required": 0,     "referrals_required": 0},
    {"level": 2, "name": "Стартапер",     "coins_required": 5000,   "referrals_required": 3},
    {"level": 3, "name": "Бизнесмен",     "coins_required": 15000,   "referrals_required": 5},
    {"level": 4, "name": "Шейх",          "coins_required": 50000,  "referrals_required": 10},
    {"level": 5, "name": "Босс",          "coins_required": 120000,  "referrals_required": 15},
    {"level": 6, "name": "Эмир",          "coins_required": 250000,  "referrals_required": 20},
    {"level": 7, "name": "Инвестор",      "coins_required": 450000,  "referrals_required": 50},
    {"level": 8, "name": "Миллионер",     "coins_required": 800000,  "referrals_required": 85},
    {"level": 9, "name": "Король Дубая",  "coins_required": 1500000, "referrals_required": 150},
    {"level": 10,"name": "Император",     "coins_required": 5000000, "referrals_required": 320}
]

# ➕ MongoDB ga yozamiz
levels.insert_many(LEVELS_DATA)

print("✅ Daraja ma’lumotlari MongoDB ga saqlandi.")
