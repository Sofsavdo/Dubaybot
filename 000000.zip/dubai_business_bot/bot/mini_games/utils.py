import random

def random_reward():
    rewards = [10, 25, 50, 100]
    return random.choice(rewards)
