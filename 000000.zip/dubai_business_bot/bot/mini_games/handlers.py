from aiogram import Dispatcher, types
from mini_games.spin_game import daily_spin
from mini_games.lootbox_game import lootbox_open
from mini_games.memory_game import play_memory_game
from mini_games.quiz_game import start_quiz

# 🎡 Daily Spin
async def spin_game_handler(message: types.Message):
    await daily_spin(message)

# 📦 Loot Box
async def lootbox_game_handler(message: types.Message):
    await lootbox_open(message)

# 🧠 Memory Game
async def memory_game_handler(message: types.Message):
    await play_memory_game(message)

# ❓ Quiz Game
async def quiz_game_handler(message: types.Message):
    await start_quiz(message)

# 🔗 Komandalarni ro'yxatdan o'tkazish
def register_minigames(dp: Dispatcher):
    dp.register_message_handler(spin_game_handler, commands=["spin"])
    dp.register_message_handler(lootbox_game_handler, commands=["lootbox"])
    dp.register_message_handler(memory_game_handler, commands=["memory"])
    dp.register_message_handler(quiz_game_handler, commands=["quiz"])
