from aiogram import types, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
import random

router = Router()

class MemoryGame(StatesGroup):
    playing = State()
    choosing = State()

@router.message(commands=["play"])
async def play_memory_game(message: types.Message, state: FSMContext):
    emojis = ['🍎', '🍌', '🍇', '🍉']
    selected = random.sample(emojis, 2)
    mixed = selected + selected
    random.shuffle(mixed)

    # O‘yin holatini saqlash
    await state.update_data(mixed=mixed, selected_positions=[])

    display = "🧠 Xotira o‘yini\nEslab qol va juftlikni top: \n"
    for emoji in mixed:
        display += f"{emoji} "
    display += "\n\n5 soniyadan keyin yashiraman!"

    await message.answer(display)
    await state.set_state(MemoryGame.playing)

    # 5 soniyadan keyin yashirish
    import asyncio
    await asyncio.sleep(5)

    display = "🧠 Xotira o‘yini\nEslab qol va juftlikni top: \n"
    for i, emoji in enumerate(mixed):
        display += f"{i+1}. [❓]\n"
    display += "\nIkkita raqam kiriting (masalan, 1 3):"

    await message.answer(display)
    await state.set_state(MemoryGame.choosing)

@router.message(MemoryGame.choosing)
async def check_choice(message: types.Message, state: FSMContext):
    data = await state.get_data()
    mixed = data['mixed']
    selected_positions = data['selected_positions']

    try:
        pos1, pos2 = map(int, message.text.split())
        pos1 -= 1  # Foydalanuvchi 1 dan boshlasa, 0 indeksga o‘tkazamiz
        pos2 -= 1

        if mixed[pos1] == mixed[pos2]:
            await message.answer(f"To‘g‘ri! {mixed[pos1]} juftligini topdingiz! 🎉")
        else:
            await message.answer(f"Noto‘g‘ri! {mixed[pos1]} va {mixed[pos2]} bir xil emas. 😔 Qaytadan urining.")
    except:
        await message.answer("Iltimos, ikkita raqam kiriting (masalan, 1 3).")

    # O‘yinni davom ettirish yoki tugatish
    await state.set_state(MemoryGame.choosing)