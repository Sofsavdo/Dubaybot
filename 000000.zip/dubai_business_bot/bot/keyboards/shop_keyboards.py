from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

# 🔘 Mahsulotni sotib olish tugmasi
def buy_button(item_id: str):
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🛍 Xarid qilish", callback_data=f"buy:{item_id}")]
        ]
    )

# 🔘 Kategoriyalar tugmalari
def category_keyboard(categories: list):
    keyboard = []
    for cat in categories:
        keyboard.append([InlineKeyboardButton(text=cat, callback_data=f"cat:{cat}")])
    keyboard.append([InlineKeyboardButton(text="🔙 Ortga", callback_data="back_to_menu")])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

# 🔘 Menyuga qaytish
def back_button():
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="🔙 Ortga", callback_data="back_to_menu")]]
    )
