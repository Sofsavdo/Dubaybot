# bot/handlers/menu_router.py
from aiogram import Router, types, F
from aiogram.types import Message
from keyboards.main_menu import main_menu
from texts.menu_texts import MAIN_MENU_BUTTONS

router = Router()

@router.message(F.text.in_([btn for row in MAIN_MENU_BUTTONS for btn in row]))
async def menu_handler(message: Message):
    await message.answer("Вы в главном меню. Выберите действие:", reply_markup=main_menu())
