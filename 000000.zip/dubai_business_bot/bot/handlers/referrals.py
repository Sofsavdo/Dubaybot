def register_referral_handlers(dp):
    pass
