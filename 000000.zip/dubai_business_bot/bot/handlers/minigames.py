from aiogram import Dispatcher, types
from minigames.spin import daily_spin
from minigames.lootbox import open_lootbox
from minigames.memory_game import start_memory_game
from minigames.quiz import start_quiz

# 🎡 Daily Spin
async def spin_game_handler(message: types.Message):
    await daily_spin(message)

# 📦 Loot Box
async def lootbox_game_handler(message: types.Message):
    await open_lootbox(message)

# 🧠 Memory Game
async def memory_game_handler(message: types.Message):
    await start_memory_game(message)

# ❓ Quiz Game
async def quiz_game_handler(message: types.Message):
    await start_quiz(message)

# 🔗 Komandalarni ro'yxatdan o'tkazish
def register_minigames(dp: Dispatcher):
    dp.register_message_handler(spin_game_handler, commands=["spin"])
    dp.register_message_handler(lootbox_game_handler, commands=["lootbox"])
    dp.register_message_handler(memory_game_handler, commands=["memory"])
    dp.register_message_handler(quiz_game_handler, commands=["quiz"])
