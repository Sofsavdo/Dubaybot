from aiogram import types
from aiogram.dispatcher import Dispatcher
from database.users import add_coins, get_user
from datetime import datetime

async def tap_game(message: types.Message):
    user_id = message.from_user.id
    user = get_user(user_id)
    if not user:
        await message.answer("Avval /start buyrug‘ini bering.")
        return

    # Har tapda 1-5 coin
    coins = 1
    add_coins(user_id, coins)
    await message.answer(f"👆 Siz {coins} coin oldingiz! Jami: {user['coins'] + coins} 🪙")

def register_tap_game(dp: Dispatcher):
    dp.register_message_handler(tap_game, text="👆 Tap")
