from aiogram import types
from aiogram.dispatcher import Dispatcher
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

async def show_menu(message: types.Message):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("👆 Tap"))
    keyboard.add(KeyboardButton("📋 Profil"))
    keyboard.add(KeyboardButton("🎁 Promo"), KeyboardButton("🛍 Do‘kon"))
    keyboard.add(KeyboardButton("🧠 Mini Games"), KeyboardButton("💸 Pul chiqarish"))
    await message.answer("📍 Asosiy menyudasiz", reply_markup=keyboard)

def register_menu(dp: Dispatcher):
    dp.register_message_handler(show_menu, commands=["menu"])
