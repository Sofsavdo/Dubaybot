from aiogram import Router, types
from aiogram.filters import Command
from keyboards.main_menu import main_menu_keyboard

router = Router()

@router.message(Command("start"))
async def start_handler(message: types.Message):
    await message.answer("🏙 Добро пожаловать в Dubai Business Bot!", reply_markup=main_menu_keyboard())

@router.callback_query(lambda c: c.data == "shop")
async def open_shop(callback: types.CallbackQuery):
    await callback.message.edit_text("🛍 Do‘kon bo‘limiga xush kelibsiz!", reply_markup=category_keyboard(["Avatarlar", "Promo Kodlar", "Boosterlar"]))
    await callback.answer()
