def register_booster_handlers(dp):
    pass
