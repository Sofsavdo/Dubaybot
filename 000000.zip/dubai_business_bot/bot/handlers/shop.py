def register_shop_handlers(dp):
    pass
