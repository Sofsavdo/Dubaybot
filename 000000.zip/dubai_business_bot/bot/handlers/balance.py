def register_balance_handlers(dp):
    pass
