from aiogram import types
from aiogram.dispatcher import Dispatcher
from database.users import create_user, add_referral, get_user

# /start komandasi
async def start_cmd(message: types.Message):
    user_id = message.from_user.id
    username = message.from_user.username or "no_username"
    args = message.get_args()

    # Agar user bazada mavjud bo‘lmasa, uni yaratamiz
    user = get_user(user_id)
    if not user:
        create_user(user_id, username)

        # Referal kod bor bo‘lsa va o‘zi o‘zini taklif qilmagan bo‘lsa
        if args:
            try:
                referrer_id = int(args)
                if referrer_id != user_id:
                    add_referral(referrer_id, user_id)
            except ValueError:
                pass  # noto‘g‘ri referal ID bo‘lsa e'tibor bermaymiz

    # Xush kelibsiz xabari
    await message.answer(
        "👋 Salom! Tap-to-Earn o‘yiniga xush kelibsiz!\n\n"
        "🧾 Profilingizni ko‘rish uchun /profile buyrug‘ini yuboring.\n"
        "💸 Coin yig‘ish va sovg‘alar sizni kutmoqda!"
    )

# Botga /start komandasi uchun handlerni ro‘yxatdan o‘tkazamiz
def register_start(dp: Dispatcher):
    dp.register_message_handler(start_cmd, commands=["start"])
