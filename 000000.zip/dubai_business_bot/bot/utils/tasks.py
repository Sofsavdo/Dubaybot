# utils/tasks.py

TASKS = [
    {
        "title": "Подпишись на канал Dubai Promo",
        "reward": 5000,
        "link": "https://t.me/dubai_promo"
    },
    {
        "title": "Сделай репост в сторис",
        "reward": 7000,
        "link": "https://t.me/dubai_promo"
    }
]

def get_active_tasks():
    return TASKS
