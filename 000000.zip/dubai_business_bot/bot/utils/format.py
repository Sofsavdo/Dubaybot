def format_coins(amount: int) -> str:
    return f"{amount:,}".replace(",", " ")

def format_money(amount: int) -> str:
    return f"{amount:,} so‘m".replace(",", " ")
