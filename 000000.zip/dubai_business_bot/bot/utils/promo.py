# utils/promo.py

PROMOS = [
    {"code": "UZUM15", "desc": "15% скидка на Uzum", "link": "https://uzum.uz", "type": "gift"},
    {"code": "YEDAX30", "desc": "30% на Yandex Eda", "link": "https://eda.yandex.ru", "type": "coin"},
]

import random

def get_random_gift_promo():
    promos = [p for p in PROMOS if p["type"] == "gift"]
    return random.choice(promos) if promos else None

def get_random_coin_promo():
    promos = [p for p in PROMOS if p["type"] == "coin"]
    return random.choice(promos) if promos else None
