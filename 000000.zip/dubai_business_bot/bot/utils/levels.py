# utils/levels.py

from pymongo import MongoClient
from config import MONGO_URI

client = MongoClient(MONGO_URI)
db = client['dubai_business']
levels_collection = db['levels']

# 🌟 Default level konfiguratsiyasi (faqat birinchi ishga tushirilganda kerak)
DEFAULT_LEVELS = {
    1: {"name": "Новичок",        "coins_required": 0,     "referrals_required": 0},
    2: {"name": "Стартапер",     "coins_required": 5000,   "referrals_required": 3},
    3: {"name": "Бизнесмен",     "coins_required": 15000,   "referrals_required": 5},
    4: {"name": "Шейх",          "coins_required": 50000,  "referrals_required": 10},
    5: {"name": "Босс",          "coins_required": 120000,  "referrals_required": 15},
    6: {"name": "Эмир",          "coins_required": 250000,  "referrals_required": 20},
    7: {"name": "Инвестор",      "coins_required": 450000,  "referrals_required": 50},
    8: {"name": "Миллионер",     "coins_required": 800000,  "referrals_required": 85},
    9: {"name": "Король Дубая",  "coins_required": 1500000, "referrals_required": 150},
    10: {"name": "Император",    "coins_required": 5000000, "referrals_required": 320}
}

# ✅ Faqat birinchi marta ishga tushirish uchun — default level konfiguratsiyasini DBga joylash
def initialize_levels():
    if levels_collection.count_documents({}) == 0:
        for level, data in DEFAULT_LEVELS.items():
            levels_collection.insert_one({
                "level": level,
                "name": data["name"],
                "coins_required": data["coins_required"],
                "referrals_required": data["referrals_required"]
            })

# 🔍 Joriy level haqida ma’lumot
def get_level_info(level):
    return levels_collection.find_one({"level": level})

# ➕ Keyingi level haqida ma’lumot
def next_level_requirements(current_level):
    return levels_collection.find_one({"level": current_level + 1})

# 📋 Barcha level sozlamalarini olish
def get_all_levels():
    return list(levels_collection.find().sort("level", 1))

# ✏️ Ma’lum bir levelni yangilash (Admin paneldan)
def update_level(level, name=None, coins_required=None, referrals_required=None):
    update_data = {}
    if name is not None:
        update_data["name"] = name
    if coins_required is not None:
        update_data["coins_required"] = coins_required
    if referrals_required is not None:
        update_data["referrals_required"] = referrals_required
    if update_data:
        levels_collection.update_one({"level": level}, {"$set": update_data})

# ✅ Foydalanuvchining yangi levelga o'tishi mumkinligini tekshirish
def can_level_up(user_data):
    current_level = user_data.get("level", 1)
    next_level = next_level_requirements(current_level)
    if not next_level:
        return False, "Вы достигли максимального уровня."

    user_coins = user_data.get("coins", 0)
    user_referrals = len(user_data.get("referrals", []))

    if user_coins >= next_level["coins_required"] and user_referrals >= next_level["referrals_required"]:
        return True, next_level
    else:
        msg = "Чтобы перейти на следующий уровень:\n"
        if user_coins < next_level["coins_required"]:
            msg += f"• Нужно {next_level['coins_required']} монет (у вас: {user_coins})\n"
        if user_referrals < next_level["referrals_required"]:
            msg += f"• Нужно {next_level['referrals_required']} рефералов (у вас: {user_referrals})"
        return False, msg
