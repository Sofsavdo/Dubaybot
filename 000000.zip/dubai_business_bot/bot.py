from aiogram import Bot, Dispatcher, executor, types
from config import TOKEN
from handlers.start import register_start_handlers
from handlers.profile import register_profile_handlers
from handlers.balance import register_balance_handlers
from handlers.shop import register_shop_handlers
from handlers.referral import register_referral_handlers
from mini_games.register import register_minigames
import logging
# bot.py yoki main.py ichida:

from handlers import promo

dp.include_router(promo.router)

logging.basicConfig(level=logging.INFO)

bot = Bot(token=TOKEN, parse_mode="HTML")
dp = Dispatcher(bot)

register_start_handlers(dp)
register_profile_handlers(dp)
register_balance_handlers(dp)
register_shop_handlers(dp)
register_referral_handlers(dp)
register_minigames(dp)

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
