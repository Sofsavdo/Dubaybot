# scripts/init_levels.py

from pymongo import MongoClient
from config import MONGO_URI

# Mongo bazaga ulanish
client = MongoClient(MONGO_URI)
db = client['dubai_business']
levels_collection = db['levels']

# 10 ta darajalar ro‘yxati
LEVELS = {
    1: {"name": "Новичок",        "coins_required": 0,     "referrals_required": 0},
    2: {"name": "Стартапер",     "coins_required": 5000,   "referrals_required": 3},
    3: {"name": "Бизнесмен",     "coins_required": 15000,   "referrals_required": 5},
    4: {"name": "Шейх",          "coins_required": 50000,  "referrals_required": 10},
    5: {"name": "Босс",          "coins_required": 120000,  "referrals_required": 15},
    6: {"name": "Эмир",          "coins_required": 250000,  "referrals_required": 20},
    7: {"name": "Инвестор",      "coins_required": 450000,  "referrals_required": 50},
    8: {"name": "Миллионер",     "coins_required": 800000,  "referrals_required": 85},
    9: {"name": "Король Дубая",  "coins_required": 1500000, "referrals_required": 150},
    10: {"name": "Император",    "coins_required": 5000000, "referrals_required": 320}
}

def initialize_levels():
    for level_number, data in LEVELS.items():
        # Har bir level bor yoki yo‘qligini tekshiramiz
        existing = levels_collection.find_one({"level": level_number})
        if not existing:
            # Agar mavjud bo‘lmasa — qo‘shamiz
            levels_collection.insert_one({
                "level": level_number,
                "name": data["name"],
                "coins_required": data["coins_required"],
                "referrals_required": data["referrals_required"]
            })
    print("✅ Barcha level ma'lumotlari MongoDB bazasiga kiritildi.")

# Agar skript to‘g‘ridan-to‘g‘ri ishga tushsa
if __name__ == "__main__":
    initialize_levels()
